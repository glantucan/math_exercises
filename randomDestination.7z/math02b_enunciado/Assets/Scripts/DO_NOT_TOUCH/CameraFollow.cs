﻿using UnityEngine;
using System.Collections;

public class CameraFollow : MonoBehaviour {
	[SerializeField] Transform playerTr;
	private Vector3 initialDistance;
	// Use this for initialization
	void Start () {
		this.initialDistance = this.transform.position - this.playerTr.position;
	}
	
	// Update is called once per frame
	void Update () {
		this.transform.position = Vector3.Lerp(this.transform.position, 
											this.playerTr.position + this.initialDistance, 0.05F);
	}
}
