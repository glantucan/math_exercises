﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

	[SerializeField] private UnityEngine.UI.Text frameCounterTextField;
	[SerializeField] private UnityEngine.UI.Text gotchasTextField;
	[SerializeField] private UnityEngine.UI.Text timeoutsTextField;
	[SerializeField] private Transform markTr;
	private int gotchasCount;
	private int timeoutsCount;
	private int maxFrameCountBeforeChange;

	private int frameCountdown;

	[SerializeField] private float v;


	//...


	void Start () {
		this.maxFrameCountBeforeChange = 150;

		//...

		this.frameCountdown = this.maxFrameCountBeforeChange;
		ShowFrameCount(this.frameCountdown);

		//...
	}

	void Update () {
		
		//... 


		/// The following senetences must be put in the right places/s to update the counters in the HUD.
		this.frameCountdown = this.frameCountdown - 1;
		ShowFrameCount(this.frameCountdown);

		gotchasCount = gotchasCount + 1;
		this.ShowGotchas(gotchasCount);

		timeoutsCount = timeoutsCount + 1;
		this.ShowTimeouts(timeoutsCount);
	}



	///////  DO NOT TOUCH
	//
	// Call this functions to show and update the frameCountDown and the new destination every time they change.
	//
	private void ShowDestination(Vector3 destPosition) {
		this.markTr.position = destPosition;
	}
	private void ShowGotchas(int gotchas) {
		gotchasTextField.text = "Gotchas: " + gotchas.ToString();
	}
	private void ShowTimeouts(int timeouts) {
		timeoutsTextField.text = "Timeouts: " + timeouts.ToString();
	}
	private void ShowFrameCount(int frame) {
		if (frame < 30){
			frameCounterTextField.color = Color.red;
		} else {
			frameCounterTextField.color = Color.black;
		}
		frameCounterTextField.text = frame.ToString() + " frames left.";
	}

}
